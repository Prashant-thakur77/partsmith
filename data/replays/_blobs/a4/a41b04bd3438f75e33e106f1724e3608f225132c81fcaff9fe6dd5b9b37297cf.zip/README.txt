PartSmith job j_261029_2584f8b1. Units: millimetres. Origin: synthetic.
