PartSmith job j_261028_894e38e0. Units: millimetres. Origin: synthetic.
