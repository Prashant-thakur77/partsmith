PartSmith job j_261028_5965127d. Units: millimetres. Origin: synthetic.
