PartSmith job j_261029_39ea05f7. Units: millimetres. Origin: synthetic.
