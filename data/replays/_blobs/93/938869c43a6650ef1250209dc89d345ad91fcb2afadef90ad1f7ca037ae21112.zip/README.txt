PartSmith job j_261028_311476fc. Units: millimetres. Origin: synthetic.
