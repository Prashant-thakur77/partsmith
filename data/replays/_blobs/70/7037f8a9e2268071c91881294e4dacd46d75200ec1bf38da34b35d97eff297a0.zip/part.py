"""Replacement knurled knob with D-bore."""

import math
import cadquery as cq

FAMILY = "knob"
TITLE = "Replacement knurled knob with D-bore"
SUMMARY = "Round control knob with grip flutes and blind D-shaped bore for 6 mm D-shaft."
TAGS = ["knob", "d-shaft", "replacement", "knurled"]
MEASURE_MAP = {
    "length": "diameter",
    "width": "diameter",
    "thickness": "height",
    "bore.diameter": "bore_d",
    "bore.flat_depth": "flat_depth",
    "side.thickness": "height",
}

# derived diameter from measured polyline ~29.7mm, height from thickness 16.0mm
PARAMS = {
    "diameter": (30.1, 15.0, 50.0, 0.1, "mm", True, "Knob diameter"),
    "height": (16.0, 6.0, 40.0, 0.1, "mm", True, "Knob height"),
    "bore_d": (6.0, 3.0, 10.0, 0.05, "mm", True, "Shaft bore diameter"),
    "flat_depth": (1.0, 0.0, 3.0, 0.05, "mm", True, "D-flat depth (0 = round bore)"),
    "bore_depth": (12.0, 4.0, 35.0, 0.1, "mm", True, "Bore depth"),
    "grip_count": (24.0, 0, 48, 1, "mm", False, "Grip flutes"),
    "grip_depth": (0.3, 0.3, 2.0, 0.05, "mm", False, "Flute depth"),
    "top_fillet": (1.7, 0.0, 6.0, 0.1, "mm", False, "Top edge fillet"),
}


def build(p: dict[str, float]) -> cq.Workplane:
    radius, height = p["diameter"] / 2, p["height"]
    knob = cq.Workplane("XY").circle(radius).extrude(height)
    f = min(p["top_fillet"], height * 0.4, radius * 0.4)
    if f > 0.1:
        knob = knob.faces(">Z").edges().fillet(f)

    n = int(p["grip_count"])
    if n > 0:
        pitch = 2 * math.pi * radius / n
        rf = min(pitch * 0.3, 2.5)
        depth = min(p["grip_depth"], rf * 0.9)
        rc = radius + rf - depth
        pts = [(rc * math.cos(2 * math.pi * i / n), rc * math.sin(2 * math.pi * i / n)) for i in range(n)]
        flutes = cq.Workplane("XY").workplane(offset=-1).pushPoints(pts).circle(rf).extrude(height + 2)
        knob = knob.cut(flutes)

    rb = min(p["bore_d"], p["diameter"] - 6.0) / 2
    depth_b = min(p["bore_depth"], height - 1.5)
    bore = cq.Workplane("XY").workplane(offset=-1).circle(rb).extrude(depth_b + 1)
    flat = min(p["flat_depth"], rb * 0.6)
    if flat > 0.05:
        keep = cq.Workplane("XY").workplane(offset=-2).center(-flat / 2, 0).rect(2 * rb - flat, 2 * rb + 2)
        bore = bore.intersect(keep.extrude(depth_b + 4))
    return knob.cut(bore)


def interfaces(p: dict[str, float]) -> list[dict[str, str | float | list[float]]]:
    depth_b = min(p["bore_depth"], p["height"] - 1.5)
    return [
        {
            "id": "shaft_bore", "label": "shaft bore", "mate_label": "shaft",
            "at": [0.0, 0.0, depth_b / 2], "axis": [0.0, 1.0, 0.0],
            "mates": [3.0, 4.0, 5.0, 6.0, 6.35, 8.0, 10.0],
        }
    ]  # fmt: skip


result = build({k: v[0] for k, v in PARAMS.items()})
