PartSmith job j_261029_9b090341. Units: millimetres. Origin: synthetic.
