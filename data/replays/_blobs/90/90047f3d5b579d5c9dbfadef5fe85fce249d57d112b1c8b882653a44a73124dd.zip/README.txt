PartSmith job j_261028_7f8bfe24. Units: millimetres. Origin: synthetic.
