PartSmith job j_261028_2fec2bd1. Units: millimetres. Origin: synthetic.
