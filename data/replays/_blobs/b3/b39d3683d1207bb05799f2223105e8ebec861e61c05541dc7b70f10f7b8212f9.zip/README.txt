PartSmith job j_261029_c409d149. Units: millimetres. Origin: synthetic.
