PartSmith job j_261029_ab1a980f. Units: millimetres. Origin: synthetic.
