PartSmith job j_261028_d7d50782. Units: millimetres. Origin: synthetic.
