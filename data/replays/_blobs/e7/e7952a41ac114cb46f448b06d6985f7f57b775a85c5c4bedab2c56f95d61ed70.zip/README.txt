PartSmith job j_261029_1bc9895a. Units: millimetres. Origin: synthetic.
