PartSmith job j_261029_bfb801ce. Units: millimetres. Origin: synthetic.
