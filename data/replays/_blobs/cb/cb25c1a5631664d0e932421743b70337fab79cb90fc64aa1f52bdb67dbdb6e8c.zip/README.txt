PartSmith job j_261028_f668f389. Units: millimetres. Origin: synthetic.
