PartSmith job j_261029_ee9e4d2d. Units: millimetres. Origin: synthetic.
