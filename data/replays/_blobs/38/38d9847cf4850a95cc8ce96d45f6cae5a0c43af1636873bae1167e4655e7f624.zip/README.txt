PartSmith job j_261028_b6175330. Units: millimetres. Origin: synthetic.
