PartSmith job j_261028_e72da60e. Units: millimetres. Origin: synthetic.
