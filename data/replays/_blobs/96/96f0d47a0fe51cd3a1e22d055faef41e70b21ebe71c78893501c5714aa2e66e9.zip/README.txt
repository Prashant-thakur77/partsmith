PartSmith job j_261028_074ddf77. Units: millimetres. Origin: synthetic.
