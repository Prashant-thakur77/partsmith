PartSmith job j_261028_5cb3a4a6. Units: millimetres. Origin: synthetic.
