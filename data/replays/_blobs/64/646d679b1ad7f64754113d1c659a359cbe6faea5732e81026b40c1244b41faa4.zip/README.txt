PartSmith job j_261028_33adc8e4. Units: millimetres. Origin: synthetic.
