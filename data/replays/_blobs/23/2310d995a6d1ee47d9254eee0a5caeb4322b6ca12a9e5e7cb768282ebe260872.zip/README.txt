PartSmith job j_261028_05ae0611. Units: millimetres. Origin: synthetic.
