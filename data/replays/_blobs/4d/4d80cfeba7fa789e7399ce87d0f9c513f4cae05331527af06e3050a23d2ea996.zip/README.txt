PartSmith job j_261028_9e643b96. Units: millimetres. Origin: synthetic.
