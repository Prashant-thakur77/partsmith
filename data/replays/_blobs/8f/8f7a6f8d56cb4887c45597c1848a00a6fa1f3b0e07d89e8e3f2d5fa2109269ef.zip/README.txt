PartSmith job j_261028_d86b060d. Units: millimetres. Origin: synthetic.
