PartSmith job j_261028_92c69348. Units: millimetres. Origin: synthetic.
