PartSmith job j_261028_6983b62e. Units: millimetres. Origin: synthetic.
