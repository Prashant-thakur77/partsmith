PartSmith job j_261028_c28d27d0. Units: millimetres. Origin: synthetic.
