PartSmith job j_261029_f559dd4d. Units: millimetres. Origin: synthetic.
