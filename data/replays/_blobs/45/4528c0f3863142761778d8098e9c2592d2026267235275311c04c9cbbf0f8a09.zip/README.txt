PartSmith job j_261028_4feddfb4. Units: millimetres. Origin: synthetic.
