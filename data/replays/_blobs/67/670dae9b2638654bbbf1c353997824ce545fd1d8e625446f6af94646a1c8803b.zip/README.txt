PartSmith job j_261029_9771df9b. Units: millimetres. Origin: synthetic.
