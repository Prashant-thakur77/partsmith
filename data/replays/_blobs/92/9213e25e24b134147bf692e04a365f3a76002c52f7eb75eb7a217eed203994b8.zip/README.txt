PartSmith job j_261029_5f32c46c. Units: millimetres. Origin: synthetic.
