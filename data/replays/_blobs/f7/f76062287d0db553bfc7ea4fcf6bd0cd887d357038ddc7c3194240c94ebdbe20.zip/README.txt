PartSmith job j_261028_b14ab42e. Units: millimetres. Origin: synthetic.
