PartSmith job j_261028_f68c112b. Units: millimetres. Origin: synthetic.
