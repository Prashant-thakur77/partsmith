PartSmith job j_261028_76d68289. Units: millimetres. Origin: synthetic.
