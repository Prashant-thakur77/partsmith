PartSmith job j_261028_1593d6ec. Units: millimetres. Origin: synthetic.
