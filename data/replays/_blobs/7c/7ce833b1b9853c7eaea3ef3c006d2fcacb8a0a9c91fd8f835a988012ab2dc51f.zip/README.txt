PartSmith job j_261029_7afa4542. Units: millimetres. Origin: synthetic.
