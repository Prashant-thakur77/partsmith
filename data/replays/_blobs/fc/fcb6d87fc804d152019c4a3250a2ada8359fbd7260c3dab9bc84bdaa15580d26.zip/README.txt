PartSmith job j_261029_4ca7f3a3. Units: millimetres. Origin: synthetic.
