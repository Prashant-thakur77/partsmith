PartSmith job j_261028_61167dbb. Units: millimetres. Origin: synthetic.
