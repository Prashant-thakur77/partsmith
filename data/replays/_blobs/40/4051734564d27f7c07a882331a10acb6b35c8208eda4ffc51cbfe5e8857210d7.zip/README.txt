PartSmith job j_261029_daf26965. Units: millimetres. Origin: synthetic.
