PartSmith job j_261029_9c8d6873. Units: millimetres. Origin: synthetic.
