PartSmith job j_261028_bee1090f. Units: millimetres. Origin: synthetic.
