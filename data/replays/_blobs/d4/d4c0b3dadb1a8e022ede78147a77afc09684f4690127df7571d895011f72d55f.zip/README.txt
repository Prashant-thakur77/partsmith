PartSmith job j_261028_39509280. Units: millimetres. Origin: synthetic.
