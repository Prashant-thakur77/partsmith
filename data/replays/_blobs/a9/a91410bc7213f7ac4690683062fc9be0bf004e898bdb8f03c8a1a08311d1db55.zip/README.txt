PartSmith job j_261028_5e59bc06. Units: millimetres. Origin: synthetic.
