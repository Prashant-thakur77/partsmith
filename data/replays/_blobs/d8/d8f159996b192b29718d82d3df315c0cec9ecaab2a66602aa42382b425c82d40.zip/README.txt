PartSmith job j_261028_5cd35468. Units: millimetres. Origin: synthetic.
