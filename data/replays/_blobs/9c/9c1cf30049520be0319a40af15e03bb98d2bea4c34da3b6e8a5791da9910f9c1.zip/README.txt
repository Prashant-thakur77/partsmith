PartSmith job j_261028_0e6101fc. Units: millimetres. Origin: synthetic.
