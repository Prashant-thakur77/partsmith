PartSmith job j_261030_d5f8831e. Units: millimetres. Origin: synthetic.
