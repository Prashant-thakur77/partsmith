PartSmith job j_261029_194351d6. Units: millimetres. Origin: synthetic.
