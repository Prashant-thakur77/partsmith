PartSmith job j_261029_37a831fc. Units: millimetres. Origin: synthetic.
