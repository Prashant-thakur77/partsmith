PartSmith job j_261028_658da702. Units: millimetres. Origin: synthetic.
