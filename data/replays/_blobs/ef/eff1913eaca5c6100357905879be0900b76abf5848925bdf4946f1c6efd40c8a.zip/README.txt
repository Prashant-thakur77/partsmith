PartSmith job j_261029_7745c8b3. Units: millimetres. Origin: synthetic.
