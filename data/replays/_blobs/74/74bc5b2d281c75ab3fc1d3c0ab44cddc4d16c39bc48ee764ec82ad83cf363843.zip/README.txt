PartSmith job j_261028_99f9e115. Units: millimetres. Origin: synthetic.
