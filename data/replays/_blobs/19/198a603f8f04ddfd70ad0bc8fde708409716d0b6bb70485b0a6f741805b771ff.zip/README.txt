PartSmith job j_261028_4c9bc2da. Units: millimetres. Origin: synthetic.
