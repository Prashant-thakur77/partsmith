PartSmith job j_261028_b7fb0ba0. Units: millimetres. Origin: synthetic.
