PartSmith job j_261029_6719dfe8. Units: millimetres. Origin: synthetic.
