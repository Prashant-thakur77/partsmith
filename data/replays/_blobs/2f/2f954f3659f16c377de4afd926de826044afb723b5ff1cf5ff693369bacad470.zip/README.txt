PartSmith job j_261028_f1769dc7. Units: millimetres. Origin: synthetic.
