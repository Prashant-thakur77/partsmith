PartSmith job j_261028_74933ad9. Units: millimetres. Origin: synthetic.
