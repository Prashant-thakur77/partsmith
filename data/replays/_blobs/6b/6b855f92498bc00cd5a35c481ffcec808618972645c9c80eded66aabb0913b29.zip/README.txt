PartSmith job j_261028_df2f5875. Units: millimetres. Origin: synthetic.
