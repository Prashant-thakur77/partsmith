PartSmith job j_261028_ec8587d5. Units: millimetres. Origin: synthetic.
