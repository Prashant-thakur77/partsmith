PartSmith job j_261029_143b6e19. Units: millimetres. Origin: synthetic.
