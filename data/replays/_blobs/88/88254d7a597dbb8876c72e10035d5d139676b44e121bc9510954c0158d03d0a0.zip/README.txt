PartSmith job j_261028_75795da3. Units: millimetres. Origin: synthetic.
