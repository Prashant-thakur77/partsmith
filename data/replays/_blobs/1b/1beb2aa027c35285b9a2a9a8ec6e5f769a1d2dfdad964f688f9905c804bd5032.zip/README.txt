PartSmith job j_261029_d9308499. Units: millimetres. Origin: synthetic.
