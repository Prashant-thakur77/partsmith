PartSmith job j_261028_4a5ef97e. Units: millimetres. Origin: synthetic.
