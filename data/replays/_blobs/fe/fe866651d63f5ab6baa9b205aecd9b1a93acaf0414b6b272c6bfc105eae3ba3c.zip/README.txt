PartSmith job j_261028_a1d8b4f3. Units: millimetres. Origin: synthetic.
