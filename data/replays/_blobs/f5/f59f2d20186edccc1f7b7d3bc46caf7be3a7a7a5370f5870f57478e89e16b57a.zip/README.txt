PartSmith job j_261028_a8c4d559. Units: millimetres. Origin: synthetic.
