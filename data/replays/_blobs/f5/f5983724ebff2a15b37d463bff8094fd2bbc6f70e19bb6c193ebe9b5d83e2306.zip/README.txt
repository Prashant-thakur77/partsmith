PartSmith job j_261105_92a408c2. Units: millimetres. Origin: synthetic.
