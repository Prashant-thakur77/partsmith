PartSmith job j_261029_c430a765. Units: millimetres. Origin: synthetic.
