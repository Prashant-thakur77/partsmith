PartSmith job j_261028_f6cc1d23. Units: millimetres. Origin: synthetic.
