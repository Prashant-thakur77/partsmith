PartSmith job j_261028_068ea33a. Units: millimetres. Origin: synthetic.
