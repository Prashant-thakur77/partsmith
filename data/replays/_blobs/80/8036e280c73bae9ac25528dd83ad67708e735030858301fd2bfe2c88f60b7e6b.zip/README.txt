PartSmith job j_261028_361a3f90. Units: millimetres. Origin: synthetic.
