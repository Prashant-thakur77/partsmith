PartSmith job j_261028_d1268acd. Units: millimetres. Origin: synthetic.
