PartSmith job j_261028_24fd5e3b. Units: millimetres. Origin: synthetic.
