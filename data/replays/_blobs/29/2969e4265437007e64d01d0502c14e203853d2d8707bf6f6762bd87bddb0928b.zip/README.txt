PartSmith job j_261029_5e9d54d1. Units: millimetres. Origin: synthetic.
