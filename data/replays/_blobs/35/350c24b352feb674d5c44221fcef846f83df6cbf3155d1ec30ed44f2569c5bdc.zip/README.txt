PartSmith job j_261028_00a3d5be. Units: millimetres. Origin: synthetic.
