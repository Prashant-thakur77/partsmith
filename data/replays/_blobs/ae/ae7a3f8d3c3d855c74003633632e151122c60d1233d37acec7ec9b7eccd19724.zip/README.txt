PartSmith job j_261028_d5a246af. Units: millimetres. Origin: synthetic.
