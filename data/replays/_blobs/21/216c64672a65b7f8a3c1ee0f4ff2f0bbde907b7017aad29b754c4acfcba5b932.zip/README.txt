PartSmith job j_261029_1c3ea2b9. Units: millimetres. Origin: synthetic.
