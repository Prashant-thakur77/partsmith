PartSmith job j_261030_ae74db07. Units: millimetres. Origin: synthetic.
