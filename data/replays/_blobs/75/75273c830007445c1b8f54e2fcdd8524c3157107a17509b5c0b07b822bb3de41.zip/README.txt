PartSmith job j_261028_2a91af48. Units: millimetres. Origin: synthetic.
