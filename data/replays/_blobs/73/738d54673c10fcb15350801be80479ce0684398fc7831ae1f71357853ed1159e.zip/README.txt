PartSmith job j_261028_074a2a41. Units: millimetres. Origin: synthetic.
