PartSmith job j_261028_c735720e. Units: millimetres. Origin: synthetic.
