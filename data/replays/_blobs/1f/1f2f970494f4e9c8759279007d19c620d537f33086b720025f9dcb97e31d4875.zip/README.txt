PartSmith job j_261029_f53c643e. Units: millimetres. Origin: synthetic.
