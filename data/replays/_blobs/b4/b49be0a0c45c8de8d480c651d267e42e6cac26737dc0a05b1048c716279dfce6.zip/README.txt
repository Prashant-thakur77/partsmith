PartSmith job j_261028_83b0c617. Units: millimetres. Origin: synthetic.
