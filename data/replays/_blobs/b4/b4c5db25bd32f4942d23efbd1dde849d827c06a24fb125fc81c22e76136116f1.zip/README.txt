PartSmith job j_261028_9f6e1265. Units: millimetres. Origin: synthetic.
