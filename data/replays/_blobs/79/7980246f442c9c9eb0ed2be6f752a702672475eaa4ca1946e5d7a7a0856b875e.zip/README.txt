PartSmith job j_261028_e09e5dce. Units: millimetres. Origin: synthetic.
