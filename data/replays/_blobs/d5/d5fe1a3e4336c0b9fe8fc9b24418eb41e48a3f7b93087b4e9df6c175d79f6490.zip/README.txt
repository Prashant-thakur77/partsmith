PartSmith job j_261028_8e1be0c8. Units: millimetres. Origin: synthetic.
