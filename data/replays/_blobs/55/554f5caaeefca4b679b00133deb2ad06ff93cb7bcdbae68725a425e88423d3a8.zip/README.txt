PartSmith job j_261028_ce1688ca. Units: millimetres. Origin: synthetic.
