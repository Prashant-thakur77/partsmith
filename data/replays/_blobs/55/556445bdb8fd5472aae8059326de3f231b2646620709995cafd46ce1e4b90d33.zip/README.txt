PartSmith job j_261028_66ce80c9. Units: millimetres. Origin: synthetic.
