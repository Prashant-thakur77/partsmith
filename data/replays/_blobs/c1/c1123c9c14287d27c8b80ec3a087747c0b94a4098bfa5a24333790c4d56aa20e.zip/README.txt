PartSmith job j_261028_eb8b331c. Units: millimetres. Origin: synthetic.
