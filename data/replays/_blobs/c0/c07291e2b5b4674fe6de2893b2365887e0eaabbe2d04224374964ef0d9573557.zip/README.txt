PartSmith job j_261029_74b387ec. Units: millimetres. Origin: synthetic.
