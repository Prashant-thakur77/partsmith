PartSmith job j_261028_534e11a8. Units: millimetres. Origin: synthetic.
