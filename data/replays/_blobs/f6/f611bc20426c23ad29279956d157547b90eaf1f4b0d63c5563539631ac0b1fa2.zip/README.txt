PartSmith job j_261028_98e6cecd. Units: millimetres. Origin: synthetic.
