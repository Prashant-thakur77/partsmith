PartSmith job j_261028_f60da1aa. Units: millimetres. Origin: synthetic.
