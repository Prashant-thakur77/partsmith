PartSmith job j_261028_e4cf1de7. Units: millimetres. Origin: synthetic.
