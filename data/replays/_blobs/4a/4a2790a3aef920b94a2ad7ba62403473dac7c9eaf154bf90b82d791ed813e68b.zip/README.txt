PartSmith job j_261028_68c49d47. Units: millimetres. Origin: synthetic.
