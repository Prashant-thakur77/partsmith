PartSmith job j_261028_4fb64f92. Units: millimetres. Origin: synthetic.
