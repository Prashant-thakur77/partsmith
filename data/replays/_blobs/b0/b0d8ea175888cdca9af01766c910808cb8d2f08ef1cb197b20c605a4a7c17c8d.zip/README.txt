PartSmith job j_261028_8c786d43. Units: millimetres. Origin: synthetic.
