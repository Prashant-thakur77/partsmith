PartSmith job j_261028_706576ac. Units: millimetres. Origin: synthetic.
