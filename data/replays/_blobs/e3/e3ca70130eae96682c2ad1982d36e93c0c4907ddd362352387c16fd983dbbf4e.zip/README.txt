PartSmith job j_261029_88627e99. Units: millimetres. Origin: synthetic.
