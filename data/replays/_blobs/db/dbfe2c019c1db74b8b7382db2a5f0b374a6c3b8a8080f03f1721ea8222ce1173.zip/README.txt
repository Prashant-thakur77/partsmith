PartSmith job j_261028_e2bb18bb. Units: millimetres. Origin: synthetic.
