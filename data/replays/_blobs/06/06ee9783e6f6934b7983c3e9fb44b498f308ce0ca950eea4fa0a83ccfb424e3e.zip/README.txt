PartSmith job j_261028_cd12d07b. Units: millimetres. Origin: synthetic.
