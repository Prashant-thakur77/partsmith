PartSmith job j_261029_dcc0a25b. Units: millimetres. Origin: synthetic.
