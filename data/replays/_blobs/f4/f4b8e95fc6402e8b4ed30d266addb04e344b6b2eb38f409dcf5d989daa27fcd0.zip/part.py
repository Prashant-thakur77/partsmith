import cadquery as cq
import math

FAMILY = "bracket"
TITLE = "Replacement l-bracket"
SUMMARY = (
    "Angle bracket: a base leg lying on the mounting face and an upright leg at one end, joined by a rounded "
    "inner bend. Screw holes in both legs; edge gussets stiffen the corner."
)
TAGS = ["bracket", "angle", "shelf", "corner", "mounting", "l-bracket"]
MEASURE_MAP = {
    "length": "length",
    "width": "width",
    "thickness": "thickness",
    "height": "height",
    "hole_1.diameter": "hole_d",
    "hole_2.diameter": "hole_d",
    "side.thickness": "height",
}

PARAMS = {  # name: (default, min, max, step, unit, affects_fit, label)
    "length": (46.4, 30.0, 70.0, 0.1, "mm", True, "Base leg length"),
    "width": (30.0, 15.0, 60.0, 0.1, "mm", True, "Bracket width"),
    "height": (31.3, 12.0, 100.0, 0.1, "mm", True, "Upright leg height"),
    "thickness": (2.5, 1.6, 8.0, 0.1, "mm", True, "Leg thickness"),
    "hole_d": (3.6, 2.5, 7.0, 0.05, "mm", True, "Screw hole diameter"),
    "base_holes": (2, 1, 3, 1, "", False, "Holes in the base leg"),
    "wall_holes": (2, 0, 3, 1, "", False, "Holes in the upright leg"),
    "gusset_count": (1, 0, 2, 1, "", False, "Edge gussets"),
    "bend_radius": (2.5, 0.0, 6.0, 0.1, "mm", False, "Inner bend radius"),
    "corner_radius": (2.0, 0.0, 8.0, 0.1, "mm", False, "Free corner radius"),
}


def spread(a: float, b: float, n: int, pitch_min: float) -> list[float]:
    """Up to n evenly spaced positions from a to b, never closer than pitch_min (holes must not overlap)."""
    if n <= 0:
        return []
    n = min(n, int(max(b - a, 0.0) // pitch_min) + 1)
    if n == 1:
        return [(a + b) / 2]
    return [a + (b - a) * i / (n - 1) for i in range(n)]


def build(p: dict[str, float]) -> cq.Workplane:
    length, width, height, t = p["length"], p["width"], p["height"], p["thickness"]
    hole_d = min(p["hole_d"], width - 3.0)
    x0 = -length / 2  # outer face of the upright leg
    xi = x0 + t  # inner face of the upright leg
    rb = min(p["bend_radius"], (length - t) * 0.3, (height - t) * 0.3)

    # L profile in the XZ plane (local x = X, local y = Z), extruded symmetrically along Y.
    sk = cq.Workplane("XZ").moveTo(x0, 0).lineTo(length / 2, 0).lineTo(length / 2, t)
    if rb > 0.05:
        k = 0.29289321881345254  # 1 - cos(45 deg)
        sk = sk.lineTo(xi + rb, t).threePointArc((xi + rb * k, t + rb * k), (xi, t + rb))
    else:
        sk = sk.lineTo(xi, t)
    part = sk.lineTo(xi, height).lineTo(x0, height).close().extrude(width / 2, both=True)

    rc = min(p["corner_radius"], width / 2 - 0.5, (length - t) / 3, (height - t) / 3)
    if rc > 0.2:
        part = part.edges("|Z and >X").fillet(rc).edges("|X and >Z").fillet(rc)

    g = int(p["gusset_count"])
    if g > 0:
        gs = min(0.45 * (length - t), 0.45 * (height - t))
        tri = [(xi - 0.2, t - 0.2), (xi + gs, t - 0.2), (xi - 0.2, t + gs)]
        ys = [width / 2 - t / 2] if g == 1 else [width / 2 - t / 2, -width / 2 + t / 2]
        for y in ys:
            part = part.union(cq.Workplane("XZ", origin=(0, y, 0)).polyline(tri).close().extrude(t / 2, both=True))

    e = 4.5  # first hole centre from the bend / free end: fixed, so holes stay put when their size changes
    xs = spread(xi + rb + e, length / 2 - e, int(p["base_holes"]), hole_d + 1.5)
    if xs:
        cut = cq.Workplane("XY").workplane(offset=-1).pushPoints([(x, 0) for x in xs]).circle(hole_d / 2)
        part = part.cut(cut.extrude(t + 2))
    zs = spread(t + rb + e, height - e, int(p["wall_holes"]), hole_d + 1.5)
    if zs:
        cut = cq.Workplane("YZ", origin=(x0 - 1, 0, 0)).pushPoints([(0, z) for z in zs]).circle(hole_d / 2)
        part = part.cut(cut.extrude(t + 2))
    return part


result = build({k: v[0] for k, v in PARAMS.items()})
