PartSmith job j_261029_205551ee. Units: millimetres. Origin: synthetic.
