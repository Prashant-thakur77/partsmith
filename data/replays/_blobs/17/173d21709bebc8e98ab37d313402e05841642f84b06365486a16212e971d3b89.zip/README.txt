PartSmith job j_261029_0d8903b6. Units: millimetres. Origin: synthetic.
