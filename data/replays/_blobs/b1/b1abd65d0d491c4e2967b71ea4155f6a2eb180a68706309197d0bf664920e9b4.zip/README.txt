PartSmith job j_261030_9dbd87f9. Units: millimetres. Origin: synthetic.
