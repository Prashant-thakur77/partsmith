PartSmith job j_261030_9deb30d6. Units: millimetres. Origin: synthetic.
