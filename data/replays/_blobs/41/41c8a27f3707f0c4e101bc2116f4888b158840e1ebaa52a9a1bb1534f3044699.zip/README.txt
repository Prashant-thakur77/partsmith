PartSmith job j_261028_444ec354. Units: millimetres. Origin: synthetic.
