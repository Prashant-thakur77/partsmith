PartSmith job j_261028_78c7be3a. Units: millimetres. Origin: synthetic.
