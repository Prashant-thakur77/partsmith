PartSmith job j_261028_9c37dec2. Units: millimetres. Origin: synthetic.
