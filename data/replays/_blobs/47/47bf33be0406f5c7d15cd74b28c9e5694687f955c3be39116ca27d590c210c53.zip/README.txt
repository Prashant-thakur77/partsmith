PartSmith job j_261028_c5f0a220. Units: millimetres. Origin: synthetic.
