PartSmith job j_261028_6f2ff284. Units: millimetres. Origin: synthetic.
