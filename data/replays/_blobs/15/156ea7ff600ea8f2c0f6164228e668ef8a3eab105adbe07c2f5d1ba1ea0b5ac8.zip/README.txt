PartSmith job j_261028_04feaf4e. Units: millimetres. Origin: synthetic.
