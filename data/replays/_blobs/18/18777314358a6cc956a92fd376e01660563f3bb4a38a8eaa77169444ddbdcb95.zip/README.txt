PartSmith job j_261029_e8bd62e7. Units: millimetres. Origin: synthetic.
