PartSmith job j_261029_d42ea8ec. Units: millimetres. Origin: synthetic.
