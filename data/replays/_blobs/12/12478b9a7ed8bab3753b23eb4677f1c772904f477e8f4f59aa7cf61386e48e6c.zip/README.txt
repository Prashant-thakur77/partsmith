PartSmith job j_261028_e22726c9. Units: millimetres. Origin: synthetic.
