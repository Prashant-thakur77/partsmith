PartSmith job j_261029_23210232. Units: millimetres. Origin: synthetic.
