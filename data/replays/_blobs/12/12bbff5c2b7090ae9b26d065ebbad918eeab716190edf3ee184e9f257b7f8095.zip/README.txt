PartSmith job j_261029_186b1e03. Units: millimetres. Origin: synthetic.
