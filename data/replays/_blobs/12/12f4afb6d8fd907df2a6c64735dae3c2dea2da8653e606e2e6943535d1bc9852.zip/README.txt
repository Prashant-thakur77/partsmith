PartSmith job j_261028_7466169a. Units: millimetres. Origin: synthetic.
