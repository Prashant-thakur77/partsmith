PartSmith job j_261029_4e4fdb76. Units: millimetres. Origin: synthetic.
